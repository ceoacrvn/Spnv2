
# SuperPOS Clone (No QR Menu) — React + Supabase

> A pragmatic, open-source POS starter for restaurants. **No QR menu** included as requested.

## What you get
- React (Vite + TypeScript), mobile-first UI (iPad-friendly)
- Supabase Auth + Row Level Security
- Core modules: POS (sell), Orders, Inventory (stock in/out), Basic Reports
- Thermal-print friendly receipt (browser print)
- Offline add-to-cart + re-sync on login
- SQL schema + policies ready to apply on Supabase
- `.env.example` to configure your Supabase URL and anon key

## Quick Start
1. Create a new Supabase project.
2. Run SQL in `supabase/schema.sql` (and `supabase/policies.sql`) in SQL editor.
3. Copy `.env.example` to `.env` and fill in your Supabase URL/key.
4. Install and run:
```bash
cd app
npm i
npm run dev
```
5. Seed: run statements in `supabase/seed.sql` if needed.

## Print Receipt
- On the POS screen, click **Settle & Print**. Uses the browser print dialog with print-optimized CSS.
- For 80mm thermal printer, set the printer defaults to 80mm paper width.

## Structure
- `app/`: Frontend React app.
- `supabase/`: SQL schema, policies, and seed data.
- `functions/` (optional later): Place for serverless functions if you want to extend securely.

## Notes
- Keep keys in `.env` and **never** commit real secrets.
- This project is intentionally small but extensible. Add features as modules without touching core.


## v2 additions
- Payment methods: Cash / Card / E-Wallet
- Offline queue: store settled orders when offline and sync when back online
- Dashboard: daily sales + COGS view (v_cogs_daily)
- CMS & Personalization: simple pages and per-user personalization (accentColor, theme)
