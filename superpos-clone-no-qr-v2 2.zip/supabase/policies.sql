
-- Enable RLS
alter table branches enable row level security;
alter table roles enable row level security;
alter table staff enable row level security;
alter table categories enable row level security;
alter table products enable row level security;
alter table stock_movements enable row level security;
alter table tables enable row level security;
alter table orders enable row level security;
alter table order_items enable row level security;
alter table payments enable row level security;

-- Allow authenticated users to read most data
create policy "authenticated read" on branches for select to authenticated using (true);
create policy "authenticated read" on roles for select to authenticated using (true);
create policy "authenticated read" on staff for select to authenticated using (auth.uid() = user_id);
create policy "authenticated read all staff" on staff for select to authenticated using (exists(select 1 from roles r where r.code in ('admin','manager') and r.code = (select role_code from staff s2 where s2.user_id=auth.uid())));

create policy "read products" on products for select to authenticated using (true);
create policy "read categories" on categories for select to authenticated using (true);
create policy "read tables" on tables for select to authenticated using (true);
create policy "read orders" on orders for select to authenticated using (true);
create policy "read order_items" on order_items for select to authenticated using (true);
create policy "read payments" on payments for select to authenticated using (true);

-- Inserts by authenticated
create policy "write own staff" on staff for insert with check (auth.uid() = user_id);
create policy "manage orders" on orders for insert to authenticated with check (true);
create policy "manage order_items" on order_items for insert to authenticated with check (true);
create policy "manage payments" on payments for insert to authenticated with check (true);
create policy "manage products" on products for insert to authenticated with check (true);
create policy "manage categories" on categories for insert to authenticated with check (true);
create policy "manage stock" on stock_movements for insert to authenticated with check (true);

-- Updates
create policy "update orders" on orders for update to authenticated using (true);
create policy "update order_items" on order_items for update to authenticated using (true);
create policy "update payments" on payments for update to authenticated using (true);
create policy "update products" on products for update to authenticated using (true);
create policy "update categories" on categories for update to authenticated using (true);
create policy "update stock" on stock_movements for update to authenticated using (true);

-- Deletes
create policy "delete orders" on orders for delete to authenticated using (true);
create policy "delete order_items" on order_items for delete to authenticated using (true);
create policy "delete payments" on payments for delete to authenticated using (true);
create policy "delete products" on products for delete to authenticated using (true);
create policy "delete categories" on categories for delete to authenticated using (true);
create policy "delete stock" on stock_movements for delete to authenticated using (true);


-- CMS and personalization policies
alter table cms_pages enable row level security;
alter table personalizations enable row level security;

create policy "read cms" on cms_pages for select to authenticated using (true);
create policy "manage cms" on cms_pages for insert,update,delete to authenticated using (true);

create policy "read personalizations" on personalizations for select to authenticated using (auth.uid() = user_id);
create policy "manage personalizations" on personalizations for insert,update,delete to authenticated using (auth.uid() = user_id);
