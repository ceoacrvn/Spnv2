
-- Core tables
create table if not exists public.branches (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  name text not null,
  created_at timestamptz default now()
);

create table if not exists public.roles (
  id uuid primary key default gen_random_uuid(),
  code text unique not null, -- admin, cashier, manager, stock
  name text not null
);

create table if not exists public.staff (
  id uuid primary key default gen_random_uuid(),
  user_id uuid unique not null, -- maps to auth.users.id
  full_name text not null,
  role_code text references roles(code) on update cascade,
  branch_id uuid references branches(id) on delete set null,
  created_at timestamptz default now()
);

create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  sort_order int default 0
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  sku text unique,
  name text not null,
  category_id uuid references categories(id) on delete set null,
  price numeric(12,2) not null default 0,
  cost numeric(12,2) not null default 0,
  is_active boolean default true
);

create table if not exists public.stock_movements (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references products(id) on delete cascade,
  qty numeric not null,
  type text not null check (type in ('IN','OUT','ADJUST')),
  note text,
  created_by uuid references staff(id) on delete set null,
  created_at timestamptz default now()
);

-- A simple stock view
create or replace view public.v_product_stock as
select p.id as product_id, coalesce(sum(case when sm.type='IN' then sm.qty when sm.type='ADJUST' then sm.qty else -sm.qty end),0) as stock
from products p
left join stock_movements sm on sm.product_id = p.id
group by p.id;

create table if not exists public.tables (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  name text not null
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  branch_id uuid references branches(id) on delete set null,
  table_code text,
  status text not null default 'OPEN' check (status in ('OPEN','SETTLED','VOID')),
  subtotal numeric(12,2) not null default 0,
  discount numeric(12,2) not null default 0,
  tax numeric(12,2) not null default 0,
  total numeric(12,2) not null default 0,
  note text,
  created_by uuid references staff(id) on delete set null,
  created_at timestamptz default now(),
  settled_at timestamptz
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders(id) on delete cascade,
  product_id uuid not null references products(id),
  name text not null,
  price numeric(12,2) not null,
  qty numeric not null,
  line_total numeric(12,2) not null
);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders(id) on delete cascade,
  method text not null check (method in ('CASH','CARD','E-WALLET','OTHER')),
  amount numeric(12,2) not null,
  paid_at timestamptz default now()
);

-- Simple P&L-ish view (sales gross)
create or replace view public.v_sales_daily as
select 
  date_trunc('day', o.settled_at) as day,
  sum(o.total) as sales_total,
  sum(o.subtotal) as sales_subtotal,
  sum(o.discount) as discount_total,
  sum(o.tax) as tax_total
from orders o
where o.status='SETTLED'
group by 1
order by 1 desc;


-- COGS: join order_items with products
create or replace view public.v_cogs_daily as
select 
  date_trunc('day', o.settled_at) as day,
  sum(oi.qty * p.cost) as cogs_total
from orders o
join order_items oi on oi.order_id = o.id
join products p on p.id = oi.product_id
where o.status='SETTLED'
group by 1
order by 1 desc;

-- CMS: simple content management
create table if not exists public.cms_pages (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  title text not null,
  content text,
  locale text default 'en',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Personalization (per user)
create table if not exists public.personalizations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  key text not null, -- e.g. 'theme','accentColor','wallpaperUrl','layout'
  value text not null,
  updated_at timestamptz default now()
);
