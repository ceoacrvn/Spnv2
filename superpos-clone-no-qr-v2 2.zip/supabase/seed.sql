
insert into roles (code,name) values 
  ('admin','Administrator'),
  ('manager','Manager'),
  ('cashier','Cashier'),
  ('stock','Stock')
on conflict (code) do nothing;

insert into branches (code,name) values ('BR1','Main Branch') on conflict (code) do nothing;

insert into categories (name, sort_order) values ('Signature',1),('Drinks',2),('Food',3);

insert into products (sku,name,category_id,price,cost) 
select 'SKU001','Pad Thai',(select id from categories where name='Food'),120,50
union all select 'SKU002','Tom Yum',(select id from categories where name='Food'),180,80
union all select 'SKU003','Thai Iced Tea',(select id from categories where name='Drinks'),60,15
on conflict (sku) do nothing;

-- Starter tables
insert into public.tables (code,name) values ('T1','Table 1'),('T2','Table 2'),('T3','Table 3')
on conflict (code) do nothing;

-- Stock IN
insert into stock_movements (product_id, qty, type, note)
select id, 50, 'IN', 'Initial stock' from products;
